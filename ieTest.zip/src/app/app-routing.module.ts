import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FirstComponentComponent } from './first-component/first-component.component';
import { TestComponent } from './test/test.component';

const routes: Routes = [
  {
    path: '', // 首頁定義
    component: FirstComponentComponent, // 要指定顯示哪個 component
  },
  {
    path: 'test', // 首頁定義
    component: TestComponent, // 要指定顯示哪個 component
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
