import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-first-component',
  templateUrl: './first-component.component.html',
  styleUrls: ['./first-component.component.css']
})
export class FirstComponentComponent implements OnInit {
  // 做一個有賣便當和飲料的格式 用form array
  public searchForm: FormGroup;
  testString = '測試文字';
  constructor(
    private builder: FormBuilder,
  ) { }

  ngOnInit() {
    this.searchForm = this.builder.group({
      name: new FormControl('', Validators.required),
      bandonList: this.builder.array(
        [this.create_bando()]
      )

    });

  }
  create_bando() {
    return this.builder.group({
      bandon_name: new FormControl('雞腿便當'),
      bandon_price: new FormControl('500'),
    });
  }

  testForm() {

    alert('is test IE');
  }

}
